# 280_TheIncredibles
Our project is about SmartBins, an innovation to the regular dustbins which can segregate the different types of wastes on it's own and an App that sends a notification to the respectable nearest dumping vehicle about the filling of the dustbin.

## Video Link for Reference of App Working
#### The app helps find nearest dumping grounds to avoid literring.
##### https://drive.google.com/file/d/1na1I7mdAfehBZSIh5EH4W5rxx4uqzE_r/view?usp=sharing
